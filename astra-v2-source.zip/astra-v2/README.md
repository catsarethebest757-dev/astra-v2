# Astra v2

A Python prototype for recommending anime, TV, and movies from liked titles and mood queries. It combines aspect embeddings, a taste adapter trained on community recommendation pairs, and lexical, tag, and graph signals.

The roadmap is to expose the recommendation path in a developer inspector, then measure what shorter vectors and quantized indexes cost in recall, memory, and latency on older devices.

## Run locally

Use Python 3.13 and install the dependencies with `python -m pip install -r requirements.txt`. Run `python -m astranami self-test` for the offline fixture suite or open `run.bat` on Windows for the launcher. First preparation fetches source data and model weights. Source datasets, caches, and trained weights are stored locally and excluded from this repository.
